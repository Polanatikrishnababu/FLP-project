package com.capgemini.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;


import com.capgemini.capstore.beans.MerchantFeedback;

import com.capgemini.capstore.dao.CustomerDao;

@Service("custService")
public class CustomerServiceImpl implements CustomerService {
	MerchantFeedback bean;
	CustomerServiceImpl()
	{bean=new MerchantFeedback();
	}
	@Autowired
	CustomerDao customerdao;
	
	
	@Override
	public List<MerchantFeedback> sendFeedback(MerchantFeedback bean) {
		customerdao.save(bean);
		return customerdao.findAll();
	}

	@Override
	public List<MerchantFeedback> viewAllFB() {
		
		return customerdao.findAll();
	}
	
	@Override
	public String getAllFeedbacks(long merchantId) {
		return ((MerchantFeedback) customerdao.findByMerchantId( merchantId)).getMerchantresponse();
		
	}
		
		@Override
		public String getAllcustomerFeedbacks(long customerId) {
			return ((MerchantFeedback) customerdao.findBycustomerId( customerId)).getCustomerFeedback();
	}
	
		
		@Override
	    public MerchantFeedback sendcustFeedback(long customerId,String customerFeedback) {
			MerchantFeedback c=customerdao.findBycustomerId(customerId);
			         c.setCustomerFeedback(customerFeedback);
			         customerdao.save(c);
			return customerdao.findBycustomerId(customerId);
		}
			
			@Override
		    public MerchantFeedback sendmerchantresponse(long merchantId,String merchantresponse) {
				MerchantFeedback c=customerdao.findByMerchantId(merchantId);
				         c.setMerchantresponse(merchantresponse);
				         customerdao.save(c);
				return customerdao.findByMerchantId(merchantId);
				
			
			
			
	
}

}
	
	
