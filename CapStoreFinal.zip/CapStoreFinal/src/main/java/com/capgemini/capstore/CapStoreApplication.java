package com.capgemini.capstore;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import com.capgemini.capstore.beans.MerchantFeedback;

@SpringBootApplication
public class CapStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoreApplication.class, args);
		/*EntityManagerFactory factory =
			      Persistence.createEntityManagerFactory("myDbFile.odb");
		EntityManager em = factory.createEntityManager();
		
		Customer customer = new Customer();
		MerchantFeedback merchantFeedback = new MerchantFeedback();
		em.getTransaction().begin();
		merchantFeedback.setCustomer(customer);
		em.getTransaction().commit();*/
	}

}
