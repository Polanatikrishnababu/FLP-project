package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.capstore.beans.MerchantFeedback;

@Repository
public interface CustomerDao extends JpaRepository<MerchantFeedback, Long> {
	@Query("from MerchantFeedback where merchantId=:merchantId")
	public MerchantFeedback findByMerchantId(@Param("merchantId") long merchantId);
	
	@Query("from MerchantFeedback where customerId=:customerId")
	public MerchantFeedback findBycustomerId(@Param("customerId") long customerId);

}
