package com.capgemini.capstore.service;




import java.util.List;
import java.util.Optional;


import com.capgemini.capstore.beans.MerchantFeedback;


public interface CustomerService {

	//Optional<MerchantFeedback> sendFeedback(MerchantFeedback merchantFeedback);
	//Optional<MerchantFeedback> sendFeedback(MerchantFeedback bean);
	//List<MerchantFeedback> viewAllFB();
	//void submitFeedback(MerchantFeedback merchantFeedback);
	List<MerchantFeedback> sendFeedback(MerchantFeedback bean);
	List<MerchantFeedback> viewAllFB();
	String getAllFeedbacks(long merchantId);
	String getAllcustomerFeedbacks(long customerId);
	MerchantFeedback sendcustFeedback(long customerId,String customerFeedback);
	MerchantFeedback sendmerchantresponse(long merchantId, String merchantresponse);
	
	
}
