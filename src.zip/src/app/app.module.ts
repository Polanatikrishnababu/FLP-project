import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustHomeComponent } from './Customers/cust-home/cust-home.component';
import { CustProfileComponent } from './Customers/cust-profile/cust-profile.component';
import { CustOrdersStatusComponent } from './Customers/cust-orders-status/cust-orders-status.component';
import { CustFeedBackComponent } from './Customers/cust-feed-back/cust-feed-back.component';
import { CustFeedBackProductComponent } from './Customers/cust-feed-back-product/cust-feed-back-product.component';
import { CustFeedBackMerchantComponent } from './Customers/cust-feed-back-merchant/cust-feed-back-merchant.component';
import { CustWishListComponent } from './Customers/cust-wish-list/cust-wish-list.component';
import { CustCartComponent } from './Customers/cust-cart/cust-cart.component';
import { CustPaymentComponent } from './Customers/cust-payment/cust-payment.component';
import {HttpClientModule,HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { CustomerService } from './Service/customer.service';


@NgModule({
  declarations: [
    AppComponent,
    CustHomeComponent,
    CustProfileComponent,
    CustOrdersStatusComponent,
    CustFeedBackComponent,
    CustFeedBackProductComponent,
    CustFeedBackMerchantComponent,
    CustWishListComponent,
    CustCartComponent,
    CustPaymentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
