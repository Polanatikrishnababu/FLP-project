import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustWishListComponent } from './cust-wish-list.component';

describe('CustWishListComponent', () => {
  let component: CustWishListComponent;
  let fixture: ComponentFixture<CustWishListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustWishListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustWishListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
