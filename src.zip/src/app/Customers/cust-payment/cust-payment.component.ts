import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-payment',
  templateUrl: './cust-payment.component.html',
  styleUrls: ['./cust-payment.component.css']
})
export class CustPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
