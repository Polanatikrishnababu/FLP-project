import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-profile',
  templateUrl: './cust-profile.component.html',
  styleUrls: ['./cust-profile.component.css']
})
export class CustProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
