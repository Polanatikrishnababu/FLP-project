import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-feed-back-product',
  templateUrl: './cust-feed-back-product.component.html',
  styleUrls: ['./cust-feed-back-product.component.css']
})
export class CustFeedBackProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
