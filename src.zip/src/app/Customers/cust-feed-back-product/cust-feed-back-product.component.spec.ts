import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustFeedBackProductComponent } from './cust-feed-back-product.component';

describe('CustFeedBackProductComponent', () => {
  let component: CustFeedBackProductComponent;
  let fixture: ComponentFixture<CustFeedBackProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustFeedBackProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustFeedBackProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
