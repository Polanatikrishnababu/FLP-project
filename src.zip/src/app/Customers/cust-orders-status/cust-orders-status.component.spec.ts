import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustOrdersStatusComponent } from './cust-orders-status.component';

describe('CustOrdersStatusComponent', () => {
  let component: CustOrdersStatusComponent;
  let fixture: ComponentFixture<CustOrdersStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustOrdersStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustOrdersStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
