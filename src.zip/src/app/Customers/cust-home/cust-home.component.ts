import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-home',
  templateUrl: './cust-home.component.html',
  styleUrls: ['./cust-home.component.css']
})
export class CustHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
